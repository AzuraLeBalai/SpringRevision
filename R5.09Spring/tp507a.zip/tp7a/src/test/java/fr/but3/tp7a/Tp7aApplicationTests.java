package fr.but3.tp7a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp7aApplicationTests {

	@Test
	void contextLoads() {
	}

}
