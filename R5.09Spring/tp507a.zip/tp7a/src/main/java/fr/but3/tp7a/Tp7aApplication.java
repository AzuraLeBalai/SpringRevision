package fr.but3.tp7a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp7aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp7aApplication.class, args);
	}

}
